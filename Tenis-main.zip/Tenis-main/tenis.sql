-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Pon 06. čen 2022, 20:28
-- Verze serveru: 10.4.14-MariaDB
-- Verze PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `tenis`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `faze`
--

CREATE TABLE `faze` (
  `idFaze` int(11) NOT NULL,
  `popis` varchar(45) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `faze`
--

INSERT INTO `faze` (`idFaze`, `popis`) VALUES
(1, 'Finále'),
(2, 'Semifinále'),
(3, 'Čtvrtfinále'),
(4, 'Osmifinále'),
(5, 'Skupinová Fáze - Skupina A'),
(6, 'Skupinová Fáze - Skupina B'),
(7, 'Skupinová Fáze - Skupina C'),
(8, 'Skupinová Fáze - Skupina D');

-- --------------------------------------------------------

--
-- Struktura tabulky `groups`
--

CREATE TABLE `groups` (
  `id` mediumint(8) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User');

-- --------------------------------------------------------

--
-- Struktura tabulky `hraci`
--

CREATE TABLE `hraci` (
  `idHraci` int(11) NOT NULL,
  `jmeno` varchar(45) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `hraci`
--

INSERT INTO `hraci` (`idHraci`, `jmeno`) VALUES
(1, 'Luboš'),
(2, 'Radim'),
(3, 'Michaela'),
(4, 'Tomáš'),
(5, 'Josef'),
(6, 'Miroslava'),
(7, 'Lenka'),
(8, 'Marie'),
(9, 'Aleš'),
(10, 'Jana'),
(11, 'Adam'),
(12, 'Lucie'),
(13, 'Matěj'),
(14, 'Václav'),
(15, 'Gabriela'),
(16, 'Lukáš');

-- --------------------------------------------------------

--
-- Struktura tabulky `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabulky `turnaje`
--

CREATE TABLE `turnaje` (
  `idTurnaje` int(11) NOT NULL,
  `nazev` varchar(45) COLLATE utf8_czech_ci DEFAULT NULL,
  `datum` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `turnaje`
--

INSERT INTO `turnaje` (`idTurnaje`, `nazev`, `datum`) VALUES
(1, 'Turnaj Uherský Brod', '2022-04-04'),
(2, 'Turnaj Uherské Hraďiště', '2022-04-06'),
(3, 'Turnaj Polešovice', '2022-04-10'),
(4, 'Turnaj Zlín', '2022-04-12'),
(5, 'Turnaj Velehrad', '2022-04-14'),
(6, 'Turnaj Otrokovice', '2022-04-16'),
(7, 'Turnaj Olomouc', '2022-04-20'),
(8, 'Turnaj Praha', '2022-04-24'),
(9, 'Turnaj Kroměříž', '2022-04-28'),
(10, 'Turnaj na podporu Ukrajiny', '2022-04-01');

-- --------------------------------------------------------

--
-- Struktura tabulky `turnaje_has_hraci`
--

CREATE TABLE `turnaje_has_hraci` (
  `Turnaje_idTurnaje` int(11) NOT NULL,
  `Hraci_idHraci` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `skupina` varchar(45) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `turnaje_has_hraci`
--

INSERT INTO `turnaje_has_hraci` (`Turnaje_idTurnaje`, `Hraci_idHraci`, `id`, `skupina`) VALUES
(1, 1, 1, 'A');

-- --------------------------------------------------------

--
-- Struktura tabulky `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) UNSIGNED DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) UNSIGNED NOT NULL,
  `last_login` int(11) UNSIGNED DEFAULT NULL,
  `active` tinyint(1) UNSIGNED DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2y$08$200Z6ZZbp3RAEXoaWcMA6uJOFicwNZaqk4oDhqTUiFXFe63MG.Daa', 'admin@admin.com', NULL, '', NULL, NULL, NULL, NULL, NULL, 1268889823, 1268889823, 1, 'Admin', 'istrator', 'ADMIN', '0');

-- --------------------------------------------------------

--
-- Struktura tabulky `users_groups`
--

CREATE TABLE `users_groups` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `group_id` mediumint(8) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(2, 1, 2);

-- --------------------------------------------------------

--
-- Struktura tabulky `zapasy`
--

CREATE TABLE `zapasy` (
  `idZapasy` int(11) NOT NULL,
  `Turnaje_has_Hraci_id` int(11) NOT NULL,
  `Turnaje_has_Hraci_id1` int(11) DEFAULT NULL,
  `Faze_idFaze` int(11) DEFAULT NULL,
  `skoreD` int(11) DEFAULT NULL,
  `skoreH` int(11) DEFAULT NULL,
  `čas` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `faze`
--
ALTER TABLE `faze`
  ADD PRIMARY KEY (`idFaze`);

--
-- Klíče pro tabulku `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Klíče pro tabulku `hraci`
--
ALTER TABLE `hraci`
  ADD PRIMARY KEY (`idHraci`);

--
-- Klíče pro tabulku `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Klíče pro tabulku `turnaje`
--
ALTER TABLE `turnaje`
  ADD PRIMARY KEY (`idTurnaje`);

--
-- Klíče pro tabulku `turnaje_has_hraci`
--
ALTER TABLE `turnaje_has_hraci`
  ADD PRIMARY KEY (`id`);

--
-- Klíče pro tabulku `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_email` (`email`),
  ADD UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  ADD UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  ADD UNIQUE KEY `uc_remember_selector` (`remember_selector`);

--
-- Klíče pro tabulku `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- Klíče pro tabulku `zapasy`
--
ALTER TABLE `zapasy`
  ADD PRIMARY KEY (`idZapasy`),
  ADD KEY `fk_Zapasy_Turnaje_has_Hraci` (`Turnaje_has_Hraci_id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pro tabulku `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pro tabulku `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Omezení pro tabulku `zapasy`
--
ALTER TABLE `zapasy`
  ADD CONSTRAINT `fk_Zapasy_Turnaje_has_Hraci` FOREIGN KEY (`Turnaje_has_Hraci_id`) REFERENCES `turnaje_has_hraci` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
