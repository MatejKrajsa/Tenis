<div style="padding-top: 3rem;">
<h2>Přidej</h2>

<?php
$this->load->helper('form');

echo form_open('administrace/pridej/send');
?>
<div class="form-group">
<?php
echo form_label('Jméno hráče', 'jmeno');
echo form_input('jmeno', '', 'class="form-control"');
?>
</div>
<?php
echo form_submit('submit', 'odeslat', 'class="btn-primary"');
?>
</div>




