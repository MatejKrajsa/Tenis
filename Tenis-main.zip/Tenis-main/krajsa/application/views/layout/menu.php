<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarColor01">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="page1">Page1</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="page2">Page2</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="page3">Page3</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="page4">Page4</a>
                            </li>
                            
                        </ul>
                        <ul class="navbar-nav ml-auto">
                             <li class="nav-item">
                                <a class="nav-link" href="registrace1"><i class="fas fa-user-plus"></i> Registrace 1
                            
                            </a>
                            </li>
                                
                                <a class="nav-link" href="prihlaseni"><i class="fas fa-sign-in-alt"></i> Přihlášení</a>
                            </li>
                        </ul>
                        
                    </div>
                </nav>   



<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

