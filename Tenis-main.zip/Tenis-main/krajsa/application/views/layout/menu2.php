<nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-primary">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarColor01">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="page1A">Page1A</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="page2A">Page2A</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="page3A">Page3A</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="page4A">Page4A</a>
                            </li>
                        </ul>
                        <ul class="navbar-nav ml-auto">
                             <li class="nav-item">
                                
                                <a class="nav-link" href="<?=base_url("odhlaseni"); ?>">Odhlaseni</a>
                            </li>
                            <li class="nav-item">
                                
                            
                            </li>
                        </ul>
                        
                    </div>
                </nav>   

                <?php //<a class="nav-link"><?php echo $user->first_name." ".$user->last_name; ?></a>