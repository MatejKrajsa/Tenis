<?php

echo heading('Přihlášení', 1);

echo form_open('login_test');
?>
<!DOCTYPE html>

<div><p class="text-danger"><?= $message; ?></p></div>

  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name="email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="password" name="password">
  </div>
 


  <button type="submit" class="btn btn-default">Submit</button>
</form>
</html>