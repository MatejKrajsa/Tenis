<?php
class ArrayLibrary {
    function __construct() {

    }

    function createBlankArray($pole) {
        $result = array();
        foreach($pole as $row) {
            $result[$row] = '';
        }

        return $result;
    }


    function inputsArray($error, $inputs) {
        $result = $this->createBlankArray($inputs);
        foreach($error as $key => $row) {
            $result[$key] = $row;
        }

        return $result;
    }



}