<?php
class TenisModel extends CI_model {
    public function __construct() {
        parent::__construct();
    }

public function getTurnaje() {
    $this->db->select('hraci.jmeno, turnaje_has_hraci.skupina');
    $this->db->from('turnaje_has_hraci');
    $this->db->join('hraci', 'hraci.idHraci = turnaje_has_hraci.Hraci_idHraci');
    $this->db->where('Turnaje_idTurnaje = 1');
    
    $result = $this->db->get()->result();
    return $result;
}

#public function delete($jmeno) {
 #   $this->db->where('jmeno', $jmeno);
  #  $this->db->delete('hraci');
#
#}

public function pridej($nazev)
{
  $data = array('nazevJmeno' => $nazev);
  $this->db->insert('hraci', $data);
}

public function getJmeno()
{
  $this->db->select();
  $this->db->from('hraci');
  
  $result = $this->db->get()->result();
  return $result;
}

function load_data()
 {
  $this->db->order_by('id', 'DESC');
  $query = $this->db->get('hraci');
  return $query->result_array();
 }

 function insert($data)
 {
  $this->db->insert('hraci', $data);
 }

 function update($data, $id)
 {
  $this->db->where('id', $id);
  $this->db->update('hraci', $data);
 }

 function delete($id)
 {
  $this->db->where('id', $id);
  $this->db->delete('hraci');
 }
}
