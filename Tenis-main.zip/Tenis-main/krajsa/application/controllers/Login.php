<?php

class Login extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->library('arraylibrary');
    }

    function registerUser() {
        $data["title"] = "Registrace";
        $data["main"] = "register";
        $this->layout->generate($data);
    }

    function loginUser() {
        $data["title"] = "Přihlášení";
        $data["main"] = "login";
        $data["message"] = $this->session->message;
        $this->layout->generate($data);
    }

    function loginTest(){
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $return = $this->ion_auth->login($email, $password);
        
        if($return){
            redirect('administrace/index');
        
        } else {
            $this->session->set_flashdata('message', 'Zadané přihlašovací údaje jsou nesprávné.');
            redirect('prihlaseni');
        }
    }
    function register1() {
        $data["title"] = "Registrace";
        $data["main"] = "registerForm1";
        $data["message"] = $this->session->message;
        $this->layout->generate($data);
    }

    function registerTest1() {

        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $confirm = $this->input->post('confirm');
        $name = $this->input->post('name');
        $surname = $this->input->post('surname');
        $email = $this->input->post('email');
        

        if ($password == $confirm) {
            $additional_data = array(
                'first_name' => $name,
                'last_name' => $surname
            );
            $return = $this->ion_auth->register($username, $password, $email, $additional_data);
            if(!$return) {
                $this->session->set_flashdata('message', 'Něco se pokazilo');
                redirect('registrace1');
            } else {
                $this->session->set_flashdata('message', 'Účet byl vytvořen, můžes se přihlásit');
                redirect('prihlaseni');
            }
        }
    }

    function register2() {
        $password_min = $this->config->item('min_password_length', 'ion_auth');
        $data["password_min"] = $password_min;
        $data["title"] = "Registrace";
        $data["main"] = "registerForm2";
        if (is_null($this->session->message)) {
            $inputs = array('name', 'surname', 'email', 'username', 'password', 'confirm');
            $data["data"] = $this->arraylibrary->createBlankArray($inputs);
        } else {
            $data["data"] = $this->session->message;
        }

        $this->layout->generate($data);

    }

    function registerTest2() {
        
        //načtení konfiguračních proměných
        $tables = $this->config->item('tables', 'ion_auth');
        $password_min = $this->config->item('min_password_lenght', 'ion_auth');

        //pole z formuláře
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $confirm = $this->input->post('confirm');
        $name = $this->input->post('name');
        $surname = $this->input->post('surname');
        $email = $this->input->post('email');


        //podmínky polí
        $this->form_validation->set_rules('name', 'jméno', 'required');
        $this->form_validation->set_rules('surname', 'přijmění', 'required');
        $this->form_validation->set_rules('email', 'email', 'required|valid_email|is_unique[' . $tables['users'] . '.email]');
        $this->form_validation->set_rules('username', 'uživatelské jméno', 'required');
        $this->form_validation->set_rules('password', 'heslo', 'required|min_lenght[' . $password_min . ']|mathces[confirm]');
        $this->form_validation->set_rules('confirm', 'potvrzení hesla', 'required');

        $return = $this->form_validation->run();
        if ($return) {
            //var_dump($this->form_validation->error_array());
            $additional_data = array(
                'first_name' => $name,
                'last_name' => $surname
            );
            $this->ion_auth->register($username, $password, $email, $additional_data);
            $this->session->set_flashdata('message', 'Účet byl vytvořen, můžes se přihlásit');
            redirect('prihlaseni');
        } else {
            $inputs = array('name', 'surname', 'email', 'username', 'password', 'confirm');
            $errors = $this->arraylibrary->inputsArray($this->form_validation->error_array(), $inputs);
            $this->session->set_flashdata('message', $errors);

            redirect('registrace2'); 
        }
    }

}