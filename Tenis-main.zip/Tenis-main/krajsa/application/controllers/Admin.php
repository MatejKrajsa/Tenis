<?php

class Admin extends Admin_controller {
    function __construct() {
        parent::__construct();
        $this->load->model('TenisModel');
    }

//  function index(){

#       $data['main'] = "admin";
 #       $data['title'] = "Administrace";
  #      $data['user'] = $this->user;

   #     $this->layout->generate($data);
  #}

  public function logoutUser()
    {
        $this->ion_auth->logout();
         redirect('/');
    }

    function page1A() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page1A";
        $data["turnaje"] = $this->TenisModel->getTurnaje();
        $this->layout->generate($data);
    }

    function page2A() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page2A";
        $data["turnaje"] = $this->TenisModel->getTurnaje();
        $this->layout->generate($data);
    }

    function page3A() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page3A";
        $data["turnaje"] = $this->TenisModel->getTurnaje();
        $this->layout->generate($data);
    }

    function page4A() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page4A";
        $this->layout->generate($data);
    }

#    public function delete($jmeno) {
 #       $this->model->delete($jmeno);
  #      redirect('administrace/page2A');
   # }

    public function pridej()
    {
        $data['title'] = 'Přidej';
        $data['main'] = 'pridej';
        $this->layout->generate($data);
    }
	
    public function pridejsend()
    {
        $this->TenisModel->pridej($this->input->post('jmeno'));
        redirect('administrace/page2A');
    }

    public function jmeno()
    {
        $data['data'] = $this->model->getJmeno();
        $data['title'] = 'Jméno';
        $data['main'] = 'jmeno';
        $this->layout->generate($data);
    }

    function index()
 {
    $data["title"] = "Úvodní stránka";
    $data["main"] = "page1A";
    $data["turnaje"] = $this->TenisModel->getTurnaje();
    $this->layout->generate($data);
    
 }

 function load_data()
 {
  $data = $this->model->load_data();
  echo json_encode($data);
 }

 function insert()
 {
  $data = array(
   'jmeno' => $this->input->post('jmeno'),
   'skupina'  => $this->input->post('skupina'),
  );

  $this->model->insert($data);
 }

 function update()
 {
  $data = array(
   $this->input->post('table_column') => $this->input->post('value')
  );

  $this->model->update($data, $this->input->post('id'));
 }

 function delete()
 {
  $this->model->delete($this->input->post('id'));
 }
    
}
