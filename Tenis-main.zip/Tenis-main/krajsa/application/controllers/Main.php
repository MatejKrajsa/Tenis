<?php

class Main extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('TenisModel');
    }

    function page1() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page1";
        $data["turnaje"] = $this->TenisModel->getTurnaje();
        $this->layout->generate($data);
    }
    
    function page2() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page2";
        $data["turnaje"] = $this->TenisModel->getTurnaje();
        $this->layout->generate($data);
    }
    
    function page3() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page3";
        $this->layout->generate($data);
    }
    
    function page4() {
        $data["title"] = "Úvodní stránka";
        $data["main"] = "page4";
        $this->layout->generate($data);
    }

      

}
