<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Main/page1';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['page1'] = 'Main/page1';
$route['page2'] = 'Main/page2';
$route['page3'] = 'Main/page3';
$route['page4'] = 'Main/page4';

$route['administrace/page1A'] = 'Admin/page1A';
$route['administrace/page2A'] = 'Admin/page2A';
$route['administrace/page3A'] = 'Admin/page3A';
$route['administrace/page4A'] = 'Admin/page4A';

$route['administrace/delete/(:num)'] = 'Admin/delete/$1';

$route['administrace/pridej'] = 'Admin/pridej';
$route['administrace/pridej/send'] = 'Admin/pridejsend';

$route['prihlaseni'] = 'Login/loginUser';
$route['login_test'] = 'Login/loginTest';
$route['administrace/index'] = 'Admin/index';
$route['odhlaseni'] = 'Admin/logoutuser';

$route['registrace1'] = 'Login/register1';
$route['registerTest1'] = 'Login/registerTest1';

$route['registrace2'] = 'Login/register2';
$route['registerTest2'] = 'Login/registerTest2';

$route['registrace3'] = 'Login/register3';
$route['registerTest3'] = 'Login/registerTest3';