<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
    function __construct() {
        parent::__construct();
    
        if(!$this->ion_auth->logged_in()) {
            $this->layout->setLayout('layout/layout_main');
    } else {
        $this->layout->setLayout('layout/layout_main_logged');
        $this->user = $this->ion_auth->user()->row();    
    }
 }
}


class Admin_controller extends CI_Controller {
  
    //var $user;
    function __construct() { 
    parent::__construct();
    
    $this->load->library('form_validation');
    
  if(!$this->ion_auth->logged_in()) {
      $this->layout->setLayout('layout/layout_main');
      redirect('admin/login');
  } else {
    $this->layout->setLayout('layout/layout_logged');
    $this->user = $this->ion_auth->user()->row();    
  }
 }
}




